/* The No-Show Shield — FIRST build (after prompt 1), kept verbatim for the
   episode. Looks right, demos well. Three defects, two of them money:
     (a) a row is a no-show only when its status is EXACTLY "no-show" —
         the export's "No Show", "noshow" and "NS" rows silently vanish;
     (b) every cancellation is charged as lost revenue at full price —
         a cancellation three weeks out costs the same as a vanished client,
         and a refilled slot still "costs" its price;
     (c) the repeat-offender list ranks by miss RATE with no minimum history,
         so clients seen exactly once sit on top at 100%. */
(function (root) {
  "use strict";
  function r2(x) { return Math.round((x + Number.EPSILON) * 100) / 100; }
  var DAY = 86400000, HOUR = 3600000;
  function parseDate(s) {
    if (!s || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;
    var t = Date.parse(s + "T00:00:00Z"); return isNaN(t) ? null : t;
  }
  function computeShieldV1(rows, settings) {
    var asOf = parseDate(settings.as_of);
    var live = [];
    rows.forEach(function (r) {
      var st = String(r.status || "").toLowerCase().trim();
      var kind = null;
      if (st === "completed") kind = "completed";
      else if (st === "no-show") kind = "no_show";               // (a) exact match only
      else if (st.indexOf("cancel") === 0) kind = "missed_cancel"; // (b) every cancellation is a loss
      if (!kind) return;                                          // anything else quietly dropped
      var d = parseDate(r.date); if (d == null || d > asOf) return;
      var hm = String(r.start || "").match(/^(\d{2}):(\d{2})$/); if (!hm) return;
      live.push({ id: r.appt_id, name: r.client_name, email: r.client_email,
        service: r.service, dateMs: d, startMs: d + (+hm[1]) * HOUR + (+hm[2]) * 60000,
        price: +r.price || 0, kind: kind });
    });
    var w90 = asOf - 89 * DAY, w12 = asOf - 364 * DAY;
    function ledger(fromMs) {
      var L = { missed_count: 0, missed_loss: 0, completed_count: 0, completed_revenue: 0 };
      live.forEach(function (r) {
        if (r.dateMs < fromMs || r.dateMs > asOf) return;
        if (r.kind === "completed") { L.completed_count++; L.completed_revenue += r.price; }
        else { L.missed_count++; L.missed_loss += r.price; }
      });
      L.missed_loss = r2(L.missed_loss); L.completed_revenue = r2(L.completed_revenue);
      return L;
    }
    var months = {};
    live.forEach(function (r) {
      var mk = new Date(r.dateMs).toISOString().slice(0, 7);
      var m = months[mk] = months[mk] || { month: mk, loss: 0, missed: 0 };
      if (r.kind !== "completed") { m.loss += r.price; m.missed++; }
    });
    var byClient = {};
    live.forEach(function (r) {
      var c = byClient[r.email] = byClient[r.email] || { email: r.email, name: r.name, total: 0, missed: 0 };
      c.total++; if (r.kind !== "completed") c.missed++;
      c.name = r.name;
    });
    var offenders = Object.keys(byClient).map(function (k) { return byClient[k]; })
      .filter(function (c) { return c.missed > 0; })
      .map(function (c) { return { client_name: c.name, email: c.email,
        miss_rate_pct: r2(c.missed / c.total * 100), missed: c.missed, total: c.total }; })
      .sort(function (a, b) { return b.miss_rate_pct - a.miss_rate_pct || b.missed - a.missed || (a.email < b.email ? -1 : 1); });
    return {
      ledgers: { last_90: ledger(w90), trail_12m: ledger(w12), all: ledger(-8640000000000000) },
      monthly: Object.keys(months).sort().map(function (k) {
        return { month: k, loss: r2(months[k].loss), missed: months[k].missed }; }),
      offenders: offenders
    };
  }
  var API = { computeShieldV1: computeShieldV1 };
  if (typeof module !== "undefined" && module.exports) module.exports = API;
  root.NSS_V1 = API;
})(typeof window !== "undefined" ? window : globalThis);
