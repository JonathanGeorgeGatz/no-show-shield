#!/usr/bin/env python3
"""Independent implementation of spec.md for The No-Show Shield.
Written from the spec text, not from the JS. Emits the same canonical JSON."""
import csv, json, re, sys, math, datetime as dt

def r2(x): return math.floor(x*100 + 0.5)/100 if x >= 0 else -math.floor(-x*100 + 0.5)/100
def money(x): return f"{r2(x):.2f}"

def parse_date(s):
    if not s or not re.match(r"^\d{4}-\d{2}-\d{2}$", s): return None
    try: return dt.datetime.strptime(s, "%Y-%m-%d")
    except ValueError: return None

def parse_dt(s):
    if not s: return None
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})", str(s).strip())
    if not m: return None
    try: return dt.datetime(int(m[1]),int(m[2]),int(m[3]),int(m[4]),int(m[5]))
    except ValueError: return None

def norm_status(raw):
    s = re.sub(r"[^a-z0-9]","", str(raw or "").lower())
    if s == "completed": return "COMPLETED"
    if s in ("noshow","ns"): return "NO_SHOW"
    if s in ("cancelled","canceled","cxl"): return "CANCELLED"
    return None

def compute(rows, S):
    LCH = S.get("late_cancel_hours",24); DEP = S.get("deposit_amount",25)
    DMIN = S.get("deposit_min_price",60); MINV = S.get("min_visits",3)
    as_of = parse_date(S["as_of"])
    bad, future, live = [], [], []
    for r in rows:
        st = norm_status(r["status"]); d = parse_date(r["date"])
        sm = re.match(r"^(\d{2}):(\d{2})$", r["start"] or "")
        booked = parse_dt(r["booked_at"])
        try: dur = float(r["duration_min"])
        except (ValueError,TypeError): dur = 0
        price = None
        if r["price"] not in ("",None):
            try: price = float(r["price"])
            except ValueError: price = None
        reason = None
        if st is None: reason = "unknown status “%s”" % (r["status"] or "")
        elif d is None: reason = "bad date"
        elif not sm: reason = "bad start time"
        elif booked is None: reason = "bad booked_at"
        elif not dur > 0: reason = "bad duration"
        elif price is None or price < 0: reason = "bad price"
        cxl = parse_dt(r["cancelled_at"])
        if not reason and st == "CANCELLED" and cxl is None:
            reason = "cancelled with no cancelled_at"
        if reason:
            bad.append((r["appt_id"], reason)); continue
        start = d + dt.timedelta(hours=int(sm[1]), minutes=int(sm[2]))
        row = dict(id=r["appt_id"], name=r["client_name"], email=r["client_email"],
                   service=r["service"], staff=r["staff"], d=d, start=start,
                   end=start+dt.timedelta(minutes=dur), price=price, st=st,
                   booked=booked, cxl=cxl)
        if d > as_of: future.append(row)
        else: live.append(row)
    for r in live:
        if r["st"] == "COMPLETED": r["bucket"]="completed"
        elif r["st"] == "NO_SHOW": r["bucket"]="no_show"
        else:
            notice = (r["start"] - r["cxl"]).total_seconds()/3600
            r["bucket"] = "late_cancel" if notice < LCH else "proper_cancel"
    by_staff = {}
    for r in live:
        if r["bucket"] == "proper_cancel": continue
        by_staff.setdefault(r["staff"],[]).append(r)
    for r in live:
        r["refilled"] = False
        if r["bucket"] != "late_cancel": continue
        vac = (r["end"]-r["start"]).total_seconds()
        for c in by_staff.get(r["staff"],[]):
            if c is r or not c["booked"] > r["cxl"]: continue
            ov = (min(c["end"],r["end"]) - max(c["start"],r["start"])).total_seconds()
            if ov >= vac*0.5: r["refilled"]=True; break
    w90 = as_of - dt.timedelta(days=89); w12 = as_of - dt.timedelta(days=364)
    def ledger(frm):
        L = dict(no_show_count=0,no_show_loss=0.0,late_cancel_count=0,late_cancel_gross=0.0,
                 refilled_count=0,refill_credit=0.0,completed_count=0,completed_revenue=0.0,
                 proper_cancel_count=0)
        for r in live:
            if frm is not None and r["d"] < frm: continue
            b = r["bucket"]
            if b=="no_show": L["no_show_count"]+=1; L["no_show_loss"]+=r["price"]
            elif b=="late_cancel":
                L["late_cancel_count"]+=1; L["late_cancel_gross"]+=r["price"]
                if r["refilled"]: L["refilled_count"]+=1; L["refill_credit"]+=r["price"]
            elif b=="completed": L["completed_count"]+=1; L["completed_revenue"]+=r["price"]
            else: L["proper_cancel_count"]+=1
        for k in ("no_show_loss","late_cancel_gross","refill_credit","completed_revenue"):
            L[k]=r2(L[k])
        L["late_cancel_net"]=r2(L["late_cancel_gross"]-L["refill_credit"])
        L["true_cost"]=r2(L["no_show_loss"]+L["late_cancel_net"])
        return L
    ledgers = dict(last_90=ledger(w90), trail_12m=ledger(w12), all=ledger(None))
    months = {}
    for r in live:
        mk = r["d"].strftime("%Y-%m")
        m = months.setdefault(mk, dict(month=mk,true_cost=0.0,no_show_count=0,late_cancel_count=0))
        if r["bucket"]=="no_show": m["true_cost"]+=r["price"]; m["no_show_count"]+=1
        elif r["bucket"]=="late_cancel":
            m["late_cancel_count"]+=1
            if not r["refilled"]: m["true_cost"]+=r["price"]
    monthly = [months[k] for k in sorted(months)]
    cells, svc = {}, {}
    for r in live:
        if r["d"] < w12: continue
        s = svc.setdefault(r["service"], dict(service=r["service"],booked_count=0,missed_count=0,missed_loss=0.0))
        s["booked_count"]+=1
        if r["bucket"] in ("no_show","late_cancel"):
            s["missed_count"]+=1
            if r["bucket"]=="no_show" or not r["refilled"]: s["missed_loss"]+=r["price"]
            wd = r["start"].weekday(); hr = r["start"].hour
            c = cells.setdefault((wd,hr), dict(weekday=wd,hour=hr,missed=0)); c["missed"]+=1
    risk = [cells[k] for k in sorted(cells)]
    services = sorted(svc.values(), key=lambda s:(-r2(s["missed_loss"]), s["service"]))
    by_client = {}
    for r in live: by_client.setdefault(r["email"],[]).append(r)
    offenders = []
    for em, rs in by_client.items():
        if len(rs) < MINV: continue
        missed = [r for r in rs if r["bucket"] in ("no_show","late_cancel")]
        if len(missed) < 2: continue
        latest = sorted(rs, key=lambda r:(r["d"], r["id"]))[-1]
        rev12 = sum(r["price"] for r in rs if r["bucket"]=="completed" and r["d"]>=w12)
        offenders.append(dict(client_name=latest["name"], email=em,
            visits=sum(1 for r in rs if r["bucket"]=="completed"),
            missed_count=len(missed),
            no_show_count=sum(1 for r in rs if r["bucket"]=="no_show"),
            late_cancel_count=sum(1 for r in rs if r["bucket"]=="late_cancel"),
            last_missed_date=max(r["d"] for r in missed).strftime("%Y-%m-%d"),
            revenue_12m=r2(rev12)))
    offenders.sort(key=lambda o:(-o["missed_count"], -o["revenue_12m"], o["email"]))
    q_forfeits=q_refunds=q_qual=q_total=0
    cstat = {}
    for r in live:
        if r["d"] < w12: continue
        q_total += 1
        qual = r["price"] >= DMIN
        if qual: q_qual += 1
        if qual and r["bucket"] in ("no_show","late_cancel"): q_forfeits += 1
        if qual and r["bucket"]=="proper_cancel": q_refunds += 1
        cs = cstat.setdefault(r["email"], dict(qual=0,misses=0))
        if qual: cs["qual"]+=1
        if r["bucket"] in ("no_show","late_cancel"): cs["misses"]+=1
    well = sum(1 for cs in cstat.values() if cs["qual"]>=1 and cs["misses"]==0)
    recovered = r2(q_forfeits*DEP); cost12 = ledgers["trail_12m"]["true_cost"]
    policy = dict(forfeits=q_forfeits, recovered=recovered, refunds_to_proper=q_refunds,
        touched_share_pct=r2(q_qual/q_total*100) if q_total else 0,
        well_behaved_touched=well,
        recovered_vs_cost_pct=r2(recovered/cost12*100) if cost12>0 else 0)
    counts = dict(completed=0,no_show=0,late_cancel=0,proper_cancel=0)
    for r in live: counts[r["bucket"]]+=1
    sum_miss = sum(r["price"] for r in live if r["bucket"] in ("no_show","late_cancel"))
    okA = sum(counts.values())+len(bad)+len(future) == len(rows)
    okB = abs(r2(ledgers["all"]["no_show_loss"]+ledgers["all"]["late_cancel_gross"]) - r2(sum_miss)) < 0.005
    okC = ledgers["all"]["refill_credit"] <= ledgers["all"]["late_cancel_gross"] + 1e-9
    okD = all(o["no_show_count"]+o["late_cancel_count"]==o["missed_count"] for o in offenders)
    recon = dict(ok=okA and okB and okC and okD,
        buckets=dict(completed=counts["completed"],no_show=counts["no_show"],
            late_cancel=counts["late_cancel"],proper_cancel=counts["proper_cancel"],
            bad=len(bad),future=len(future),total=len(rows)))
    return dict(bad=bad, ledgers=ledgers, monthly=monthly, risk=risk, services=services,
                offenders=offenders, policy=policy, recon=recon)

def canonical(res):
    L = {}
    for w in ("last_90","trail_12m","all"):
        s = res["ledgers"][w]
        L[w] = dict(no_show_count=s["no_show_count"], no_show_loss=money(s["no_show_loss"]),
            late_cancel_count=s["late_cancel_count"], late_cancel_gross=money(s["late_cancel_gross"]),
            refilled_count=s["refilled_count"], refill_credit=money(s["refill_credit"]),
            late_cancel_net=money(s["late_cancel_net"]), true_cost=money(s["true_cost"]),
            completed_count=s["completed_count"], completed_revenue=money(s["completed_revenue"]),
            proper_cancel_count=s["proper_cancel_count"])
    return dict(
        bad_rows=[f"{i}|{r}" for i,r in res["bad"]],
        ledgers=L,
        monthly=[f'{m["month"]}|{money(m["true_cost"])}|{m["no_show_count"]}|{m["late_cancel_count"]}' for m in res["monthly"]],
        risk=[f'{c["weekday"]}-{c["hour"]}|{c["missed"]}' for c in res["risk"]],
        services=[f'{s["service"]}|{s["booked_count"]}|{s["missed_count"]}|{money(s["missed_loss"])}' for s in res["services"]],
        offenders=["|".join([o["client_name"],o["email"],str(o["visits"]),str(o["missed_count"]),
            str(o["no_show_count"]),str(o["late_cancel_count"]),o["last_missed_date"],money(o["revenue_12m"])]) for o in res["offenders"]],
        policy=dict(forfeits=res["policy"]["forfeits"], recovered=money(res["policy"]["recovered"]),
            refunds_to_proper=res["policy"]["refunds_to_proper"],
            touched_share_pct=f'{res["policy"]["touched_share_pct"]:.2f}',
            well_behaved_touched=res["policy"]["well_behaved_touched"],
            recovered_vs_cost_pct=f'{res["policy"]["recovered_vs_cost_pct"]:.2f}'),
        reconciliation=dict(ok=res["recon"]["ok"], buckets=res["recon"]["buckets"]))

if __name__ == "__main__":
    csv_path = sys.argv[1]
    S = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {"as_of":"2026-10-06"}
    with open(csv_path, newline="") as f:
        rows = list(csv.DictReader(f))
    print(json.dumps(canonical(compute(rows, S)), sort_keys=True))
