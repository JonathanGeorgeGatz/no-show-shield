# The No-Show Shield

One HTML file. Open `No_Show_Shield.html` in any browser, paste your appointment export,
press "Read my history". Nothing is uploaded anywhere — the page works with the network cable
unplugged.

What it answers:
- What no-shows and late cancellations actually cost — the last 90 days and the last 12 months,
  with re-filled slots credited back and proper cancellations counted as free.
- When it happens (weekday × hour), and to which services.
- Who keeps doing it — with what each of those clients spent in the last 12 months next to their
  miss count, so the list informs a conversation instead of a purge.
- What a deposit policy ($ amount + price threshold, forfeited on no-show/late cancel) would have
  collected on your real history, how many bookings it touches, and how many clean customers
  would feel it. Clearly marked SIMULATED.

Settings on the board: late-cancel window (hours), deposit amount, deposit price threshold,
offender minimum visits, as-of date. A reconciliation line proves every row landed in exactly one
bucket and the dollars tie out — if it ever fails it prints DO NOT TRUST THIS BOARD.

Files:
- `No_Show_Shield.html` — the tool (single file, offline)
- `PROMPTS.md` — the three exact prompts from the episode
- `sample_appointments.csv` — the fictional Copperpaw Grooming Co. fixture from the episode
  (all names and emails invented, @example.com)
- `engine_v1.js` — the first build, kept verbatim, bugs and all, for comparison
- `checker.py` — the independent Python implementation used to verify the engine
  (200 generated businesses, 84,162 fields, 0 disagreements at ship)
- `spec.md` — the written specification both implementations follow

From the YouTube series **Build It With AI** — Episode 10. CSV columns expected:
appt_id, client_name, client_email, service, staff, date (YYYY-MM-DD), start (HH:MM),
duration_min, price, status (completed / no-show / cancelled, spelling variants handled),
booked_at, cancelled_at.
