# The No-Show Shield — engine specification (both implementations follow THIS text)

Input: appointment rows parsed from CSV with columns
appt_id, client_name, client_email, service, staff, date (YYYY-MM-DD), start (HH:MM),
duration_min, price, status, booked_at (ISO "YYYY-MM-DD HH:MM"), cancelled_at (ISO or empty).

Settings (defaults): late_cancel_hours=24 · deposit_amount=25 · deposit_min_price=60 ·
min_visits=3 · as_of (date, YYYY-MM-DD).

All money rounded half-up to cents at each named output (r2). Times are naive local.

## 1. Normalization
- status, lowercased, non-alphanumerics stripped: "completed"→COMPLETED; "noshow"|"ns"→NO_SHOW;
  "cancelled"|"canceled"|"cxl"→CANCELLED. Anything else → BAD row, reason "unknown status <raw>".
- BAD rows (each listed with appt_id + reason, excluded from every other number):
  unparseable/missing date, start, booked_at, duration_min ≤ 0, price missing or < 0,
  CANCELLED row with empty/unparseable cancelled_at, cancelled_at or booked_at AFTER appointment
  start for a CANCELLED row is NOT bad (data happens) — keep, but a cancelled_at after start
  classifies as LATE (notice ≤ 0).
- Appointments with date > as_of are FUTURE rows: excluded from every number, counted in
  reconciliation as FUTURE.

## 2. Classification (every non-BAD, non-FUTURE row lands in exactly ONE bucket)
- COMPLETED → bucket completed.
- NO_SHOW → bucket no_show.
- CANCELLED: notice_hours = (appointment start datetime − cancelled_at) in hours (may be ≤ 0).
  notice_hours < late_cancel_hours → bucket late_cancel, else bucket proper_cancel.
  (STRICT <: a cancellation exactly at the window boundary is proper.)

## 3. Refill credit (late_cancel only)
A late-cancelled appointment is REFILLED iff there exists another row (any bucket except
proper_cancel and BAD/FUTURE) with the same staff, booked_at > this row's cancelled_at, whose
[start, start+duration) overlaps the vacated [start, start+duration) by ≥ 50% of the vacated
duration. A refilled late cancel contributes 0 to cost and is counted/summed separately.
No-shows are never refilled (no notice was given).

## 4. The ledger (windows: LAST_90 = (as_of − 89 days)..as_of inclusive by appointment date;
ALL = everything ≤ as_of; TRAIL_12M = (as_of − 364 days)..as_of)
Per window: no_show_count, no_show_loss = Σ price;
late_cancel_count, late_cancel_gross = Σ price, refilled_count, refill_credit = Σ price of
refilled, late_cancel_net = gross − credit; true_cost = no_show_loss + late_cancel_net;
completed_count, completed_revenue; proper_cancel_count.
Monthly series (ALL window, calendar months ascending): {month "YYYY-MM", true_cost, no_show_count,
late_cancel_count} — months with no appointments at all are omitted; months with appointments but
zero cost appear with zeros.

## 5. Risk map (TRAIL_12M): for each (weekday 0=Mon..6=Sun, hour of start): missed = no_show +
late_cancel count; cell list only non-zero cells. By-service table (TRAIL_12M): per service name:
booked_count (all buckets), missed_count, missed_loss (no_show price + non-refilled late price),
sorted by missed_loss desc, ties by service name asc.

## 6. Repeat offenders (ALL window; identity = exact client_email)
Clients with total appointment count (all buckets) ≥ min_visits AND missed_count ≥ 2, where
missed = no_show or late_cancel (refilled still counts as missed — behaviour, not dollars).
Output per client sorted by missed_count desc, then trail-12m completed revenue desc, then email
asc: {client_name (the name on their latest row by date then appt_id), email, visits = completed
count ALL, missed_count, no_show_count, late_cancel_count, last_missed_date,
revenue_12m = Σ price of COMPLETED rows in TRAIL_12M}.

## 7. Policy simulator (TRAIL_12M, qualifying = price ≥ deposit_min_price)
Over qualifying rows: forfeits = no_show_count_q + late_cancel_count_q (refilled late cancels
STILL forfeit — the deposit is policy, the refill is luck); recovered = forfeits × deposit_amount;
refunds_to_proper = proper_cancel_count_q (they get the deposit back);
touched_share = qualifying row count ÷ all row count (both excluding BAD/FUTURE, within TRAIL_12M);
well_behaved_touched = count of clients (by email) with ≥1 qualifying row in TRAIL_12M and zero
missed rows (no_show or late_cancel, any price) in TRAIL_12M — the clean customers who would be
asked for a deposit.
Also recovered_vs_cost_pct = recovered ÷ true_cost(TRAIL_12M) × 100 (r2; 0 if cost is 0).

## 8. Reconciliation (prints on the board)
completed + no_show + late_cancel + proper_cancel + BAD + FUTURE == total input rows, AND
no_show_loss(ALL) + late_cancel_gross(ALL) == Σ price over no_show∪late_cancel rows (ALL), AND
refill_credit ≤ late_cancel_gross, AND every offender's no_show_count + late_cancel_count ==
their missed_count. All four hold → "RECONCILED row-for-row". Any fails → "DO NOT TRUST THIS
BOARD" with the failing identity.

Canonical JSON for comparison: stable key order, all money as strings with 2 decimals,
counts as integers, shares as percentage strings with 2 decimals.
